import React from 'react'

function Alert() {
  return (
    <div className='alert'>Title or text description can't be empty</div>
  )
}

export default Alert